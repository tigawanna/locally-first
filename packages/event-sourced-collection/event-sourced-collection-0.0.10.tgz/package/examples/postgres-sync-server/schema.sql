-- Minimal sync schema. Pair with handlers.ts.

CREATE TABLE events (
  global_seq        BIGSERIAL PRIMARY KEY,
  event_id          TEXT NOT NULL UNIQUE,
  collection_id     TEXT NOT NULL,
  type              TEXT NOT NULL CHECK (type IN ('insert', 'update', 'delete')),
  key               TEXT NOT NULL,
  payload           JSONB NOT NULL,
  previous          JSONB,
  tx_id             TEXT NOT NULL,
  client_id         TEXT NOT NULL,
  schema_version    INTEGER NOT NULL DEFAULT 1,
  client_timestamp  BIGINT NOT NULL,
  server_timestamp  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_events_global_seq ON events (global_seq);
CREATE INDEX idx_events_row ON events (collection_id, key, global_seq DESC);

-- Stable identity of THIS event store. Regenerate (or wipe this table) only when
-- the log is intentionally reset — clients treat a change as "cursor is junk".
CREATE TABLE sync_backend (
  id          INTEGER PRIMARY KEY CHECK (id = 1),
  backend_id  TEXT NOT NULL
);

INSERT INTO sync_backend (id, backend_id)
VALUES (1, gen_random_uuid()::text)
ON CONFLICT (id) DO NOTHING;
